/* See LICENSE of license details. */
#ifndef _HBIRD_SYS_STUB_H
#define _HBIRD_SYS_STUB_H

static inline int _stub(int err)
{
  return -1;
}

#endif /* _HBIRD_SYS_STUB_H */
